import { createTheme } from '@mui/material/styles';

const theme = createTheme({
    container: {
        margin: 100,
        padding: 20,
        boxShadow: 'rgba(100, 100, 111, 0.2) 0px 7px 29px 0px',
        flexGrow: 1,
        textAlign: "center"
    },
    cityCard: {
        margin: 20,
        marginLeft: 100,
        marginRight: 100,
    },
    cityBox: {
        backgroundColor: '#d3eaf2',
        padding: 20,
        margin: 18,
        marginRight: 140,
        marginLeft: 140,
        borderRadius: 20,
    }
});

export default theme;