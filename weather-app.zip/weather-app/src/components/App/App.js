import { useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import City from '../City/City'
import { useTheme } from '@mui/material/styles';

function App() {
  const theme = useTheme();

  const [cities, setCities] = useState(null)

  async function fetchCities () {
    try {
      const endpoint = "http://localhost:8000/all_cities"
      fetch(endpoint).then((response) => {
        return response.json()
      }).then((data) => {
        setCities(data);
      })
    } catch (e) {
      console.log(e);
    }
  }

  useEffect(() => {
    fetchCities();
  }, [])

  return (<Box style={theme.container}> 
    <Typography variant="h2"> Welcome to our weather app!</Typography>
    <Typography variant="body1"> Granite State Code Camp 2022</Typography>
    {cities && cities.map((city) => {
      return (
        <City
          address={city.address}
          location={city.location}
          image={city.image}
          precipitation={city.data.precipitation}
          humidity={city.data.precipitation}
          wind={city.data.wind}
          currentFarenheit={city.data.currentFarenheit}
          currentCelsius={city.data.currentCelsius}
          time={city.data.time}
          forecast={city.data.forecast}
        >
        </City>
      )
    })}
  </Box>)
}

export default App;