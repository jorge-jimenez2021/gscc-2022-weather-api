import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { useTheme } from '@mui/material/styles';


function ForecastTable(props) {
  const { forecast } = props;
  const theme = useTheme();
  return (
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
            <TableRow>
                <TableCell>Day</TableCell>
                <TableCell align="right">Farenheit&nbsp;(f)</TableCell>
                <TableCell align="right">Celsius&nbsp;(c)</TableCell>
                <TableCell align="right">Description</TableCell>
                <TableCell align="right">Humidity</TableCell>
                <TableCell align="right">Wind</TableCell>
            </TableRow>
        </TableHead>
        <TableBody>
        {forecast.map((forecast) => (
            <TableRow
              key={forecast.day}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {forecast.day}
              </TableCell>
              <TableCell align="right">{`${forecast.tempF} F`}</TableCell>
              <TableCell align="right">{`${forecast.tempC} C`}</TableCell>
              <TableCell align="right">{forecast.desc}</TableCell>
              <TableCell align="right">{forecast.humidity}</TableCell>
              <TableCell align="right">{forecast.wind}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

export default ForecastTable;