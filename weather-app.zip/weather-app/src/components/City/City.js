import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { useTheme } from '@mui/material/styles';
import CardMedia from '@mui/material/CardMedia';
import ForecastTable from '../ForecastTable/ForecastTable';

function City(props) {
  const { 
    address, 
    location, 
    image, 
    precipitation, 
    humidity,
    wind,
    currentFarenheit,
    currentCelsius,
    time,
    forecast
  } = props;
  const theme = useTheme();
  return (
  <Card style={theme.cityCard}>
    <CardMedia
        component="img"
        height="240"
        image={image}
    />
    <CardContent>
        <Box style={theme.cityBox}>
          <Typography variant="h5"> {address} </Typography>
          <Typography variant="body1"> {location} </Typography>
          <Typography variant="h4"> {time} </Typography>
        </Box>
        <Typography variant="h3"> {`${currentFarenheit} F | ${currentCelsius} C`} </Typography>
        <Typography variant="body1"> {`Precipitation: ${precipitation}%`} </Typography>
        <Typography variant="body1"> {`Humidity: ${humidity}%`} </Typography>
        <Typography variant="body1"> {wind} </Typography>
        <ForecastTable forecast={forecast}></ForecastTable>
    </CardContent>
  </Card>
  );
}

export default City;